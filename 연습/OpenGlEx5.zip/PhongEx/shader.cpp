#include <stdlib.h>
#include <gl/glew.h>
#include <gl/glut.h>
#include "shaders.h"

char *textFileRead(const char* filename) {
	FILE* fp;
	char* content = NULL;

	int count = 0;

	if (filename != NULL) {
		fopen_s(&fp, filename, "rt");

		if (fp != NULL) {

			fseek(fp, 0, SEEK_END);
			count = ftell(fp);
			rewind(fp);

			if (count > 0) {
				content = (char*)malloc(sizeof(char) * (count + 1));
				count = fread(content, sizeof(char), count, fp);
				content[count] = '\0';
			}
			fclose(fp);
		}
	}
	return content;
}

void programerrors(const GLint program) {
	int infologLength = 0;
	int charsWritten = 0;
	char* infoLog;

	glGetProgramiv(program, GL_INFO_LOG_LENGTH, &infologLength);

	if (infologLength > 0)
	{
		infoLog = (char*)malloc(infologLength);
		glGetProgramInfoLog(program, infologLength, &charsWritten, infoLog);
		printf("%s\n", infoLog);
		free(infoLog);
	}
}

void shadeerrors(const GLint shader) {
	int infologLength = 0;
	int charsWritten = 0;
	char* infoLog;

	glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &infologLength);

	if (infologLength > 0)
	{
		infoLog = (char*)malloc(infologLength);
		glGetShaderInfoLog(shader, infologLength, &charsWritten, infoLog);
		printf("%s\n", infoLog);
		free(infoLog);
	}
}

GLuint initshaders(GLenum type, const char* filename) {
	GLuint s;
	char* t;

	s = glCreateShader(type);

	t = textFileRead(filename);

	const char* tt = t;
	glShaderSource(s, 1, &t, NULL);

	free(t);

	glCompileShader(s);

	return s;
}

GLuint initprogram(GLuint vertexshader, GLuint fragmentshader) {
	GLuint p;

	p = glCreateProgram();

	glAttachShader(p, vertexshader);
	glAttachShader(p, fragmentshader);

	glLinkProgram(p);

	glUseProgram(p);

	return p;
}